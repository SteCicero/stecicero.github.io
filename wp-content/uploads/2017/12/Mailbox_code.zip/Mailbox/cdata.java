public class cdata <T>
{
		T msg;
		String mit;
		int numporta;
}