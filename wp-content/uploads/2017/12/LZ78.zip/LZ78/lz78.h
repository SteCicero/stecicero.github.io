/* dictionary.h
Created by Stefano Cicero on 30/11/2016.
*/

#include "bitfile.h"
#include "dictionary.h"

void decompress(char* fname_in, char* fname_out);

void compress(char* fname_in, char* fname_out);
